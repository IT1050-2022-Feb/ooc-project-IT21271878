#include<iostream>
#include"newcustomer.h"

newcustomer::newcustomer(){
cout<<"default constructer newcustomer() called"<<endl;
}
newcustomer::newcustomer(string name,string email,int mobileno){
name=name;
email=email;
mobileno=mobileno;

}
newcustomer::~newcustomer(){
cout<<"destructed"<<endl;
}
