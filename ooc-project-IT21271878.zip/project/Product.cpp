#include <iostream>
#include "Product.h"

Product::Product() {
cout << "Default Product() called" << endl;
}
Product::Product(string product Id, string product Name,, double price, double discount)
{
Product Id = product Id;;
Name=name;
price = price;
Discount = discount;
}
Product::~Product()
{
cout << "Destructed" << endl;
}
