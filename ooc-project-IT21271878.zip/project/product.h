#include <string>
using namespace std;

class Product {
protected:
string Product name;
string Product Id;
double price;;
double Discount;

public:
Product(int no);
Product(string product Id, string product Name, double price, double discount);
void viewProductDetails();
};
