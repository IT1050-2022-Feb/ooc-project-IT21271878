#include<string>
using namespace std;

class newcustomer{
protected:
string name;
string email;
int mobileno;

public:
newcustomer(string name,string email,intmobileno);
void viewcustomerdetails();
};
